﻿using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;

public class MousePointFields : MonoBehaviour {

	// Target field color
	public Color target = Color.red;

	// Array containing marked fields
	public static bool[,] hitbox = new bool[3,3];

	// Field indexes in hitbox array
	int idx, idy;

	// Left Mouse Button hold flag
	bool lmbHold=false;

	// Sets all hitbox flags to false
	void clearHitbox(){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				hitbox[i,j]=false;
			}
		}
	}

	// Print all hitbox flags to console
	void printHitbox(){
		string str="HITBOX:\n";
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(hitbox[i,j]==true) str+="1";
				else str+="0";
				str+=" ";
			}
			str+="\n";
		}
		str+="Marked: ";
		str+=countMarkedFields().ToString();
		print(str);
	}

	// Return number of marked fields 
	int countMarkedFields(){
		int marked=0;
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(hitbox[i,j]==true){
					marked++;
				}
			}
		}
		return marked;
	}
		
	// Execute when started
	void Start()
	{
		clearHitbox();
		switch (gameObject.name){
			case "TopLeftCombatField":
				idx=0; idy=0; break;
			case "TopCombatField":
				idx=0; idy=1; break;
			case "TopRightCombatField":
				idx=0; idy=2; break;
			case "LeftCombatField":
				idx=1; idy=0; break;
			case "MiddleCombatField":
				idx=1; idy=1; break;
			case "RightCombatField":
				idx=1; idy=2; break;
			case "BottomLeftCombatField":
				idx=2; idy=0; break;
			case "BottomCombatField":
				idx=2; idy=1; break;
			case "BottomRightCombatField":
				idx=2; idy=2; break;
		}
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (countMarkedFields()==3){
			printHitbox();
		}
		if (Input.GetMouseButtonDown(0)){
			clearHitbox();
		}
		if (Input.GetMouseButton(0)){
			lmbHold=true;
		}
		else {
			lmbHold=false;
		}
		gameObject.GetComponent<Renderer>().enabled=hitbox[idx,idy];
		gameObject.GetComponent<Renderer>().material.color=target;
	}

	// Set fields colors and flags when mouse is over
	public void OnMouseOver()
	{
		if (Input.GetMouseButton(0)){
			target = Color.white;
		}
		else target = Color.green;
		if (countMarkedFields()<3) hitbox[idx,idy] = true;
	}

	// When button isn't held, set hitbox flag to false
	public void OnMouseExit()
	{
		if(!lmbHold){
			hitbox[idx,idy] = false;
		}
	}
}